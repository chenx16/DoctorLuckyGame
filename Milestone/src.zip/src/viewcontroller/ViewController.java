package viewcontroller;

import gameworld.WorldInterface;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import player.PlayerInterface;
import view.GamePanel;
import view.GameView;
import view.InfoPanel;

public class ViewController extends KeyAdapter {
  private GameView view;
  private WorldInterface world;

  public ViewController(GameView view, WorldInterface world) {
    this.view = view;
    this.world = world;

    // Registering event listeners
//    view.registerMouseListener(new GameMouseListener());
//    view.registerKeyListener(new GameKeyListener());
    this.view.registerKeyListener(new GameKeyListener());
//    registerMouseListener(view.getGamePanel());
  }

  private void updateTurnInfo() {
    PlayerInterface currentPlayer = world.getTurn();
    view.updateTurnInfo(currentPlayer);
  }

  // Handles mouse clicks on player representations
  private class GameMouseListener implements MouseListener {
    @Override
    public void mouseClicked(MouseEvent e) {
      // Get player information based on the click position
      PlayerInterface selectedPlayer = view.getPlayerAtLocation(e.getPoint());
      if (selectedPlayer != null) {
        String description = selectedPlayer.getDescription();
        view.showMessage(description);
      }
    }

    // Other required MouseListener methods
    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }
  }

  public void registerMouseListener(GamePanel gamePanel) {
    gamePanel.addMouseListener(new MouseAdapter() {
      @Override
      public void mouseClicked(MouseEvent e) {
        PlayerInterface clickedPlayer = view.getPlayerAtLocation(e.getPoint());
        if (clickedPlayer != null) {
          view.showMessage("Player clicked: " + clickedPlayer.getName());
        }
      }
    });
  }

  // Handles keyboard commands
  private class GameKeyListener implements KeyListener {
    @Override
    public void keyPressed(KeyEvent e) {
      PlayerInterface currentPlayer = world.getTurn();
      ViewCommand command = null;
      InfoPanel infoPanel = view.getInfoPanel();

      switch (e.getKeyCode()) {
        case KeyEvent.VK_M:
          // Move command, ask for room index or logic to select room
          int roomIndex = view.promptForRoom();
          command = new MoveCommand(world, currentPlayer, roomIndex);
          break;
        case KeyEvent.VK_P:
          // Pick up item command
          String itemName = view.promptForItem();
          command = new PickUpCommand(world, currentPlayer, itemName);
          break;
        case KeyEvent.VK_L:
          // Look command
          command = new LookCommand(world, currentPlayer, infoPanel);
          break;
        case KeyEvent.VK_A:
          // Attempt attack command
          String item = view.promptForInventoryItem();
          command = new AttackCommand(world, currentPlayer, infoPanel, item);
          break;
        default:
          view.showErrorMessage("Invalid key pressed");
          return;
      }

      if (command != null) {
        command.execute();
        updateTurnInfo(); // Update turn information after the command
      }
    }

    // Other required KeyListener methods
    @Override
    public void keyReleased(KeyEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }
  }
}
