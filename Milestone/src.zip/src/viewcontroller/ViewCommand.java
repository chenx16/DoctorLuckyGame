package viewcontroller;

public interface ViewCommand {

  void execute();

}
