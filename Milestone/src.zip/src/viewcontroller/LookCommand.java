package viewcontroller;

import gameworld.WorldInterface;
import player.PlayerInterface;
import view.InfoPanel;

public class LookCommand implements ViewCommand {
  private final WorldInterface world;
  private final PlayerInterface player;
  private final InfoPanel infoPanel;

  public LookCommand(WorldInterface world, PlayerInterface player, InfoPanel infoPanel) {
    this.world = world;
    this.player = player;
    this.infoPanel = infoPanel;
  }

  @Override
  public void execute() {
    // Fetch and display information about the player's surroundings

    int currRoomInd = world.getTurn().getCurrentRoom().getRoomInd();
    String surroundingsInfo = world.turnHumanPlayer("look", currRoomInd, null);
    infoPanel.updateInfo(surroundingsInfo);

  }
}
